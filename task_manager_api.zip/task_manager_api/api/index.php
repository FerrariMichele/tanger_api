<?php
// Database connection setup
$host = 'localhost';
$username = 'micheleferrari'; // Update with your DB username
$password = '';     // Update with your DB password
$database = 'my_micheleferrari'; // Update with your DB name

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Parse the current URL path
$request = trim($_SERVER['REQUEST_URI'], '/');
$request = explode('?', $request)[0]; // Remove query parameters
$segments = explode('/', $request);

// Basic Router
switch ($segments[1]) {
    case 'api':
        if (isset($segments[2])) {
            switch ($segments[2]) {
                case 'users':
                    handleUsers($segments, $conn);
                    break;
                case 'projects':
                    handleProjects($segments, $conn);
                    break;
                case 'tasks':
                    handleTasks($segments, $conn);
                    break;
                case 'documents':
                    handleDocuments($segments, $conn);
                    break;
                case 'roles':
                    handleRoles($segments, $conn);
                    break;
                case 'modifications':
                    handleModifications($segments, $conn);
                    break;
                default:
                    sendResponse(404, "API endpoint not found.");
            }
        } else {
            sendResponse(400, "Invalid API request.");
        }
        break;

    default:
        sendResponse(404, "Resource not found.");
}

// Functions to handle API routes
function handleUsers($segments, $conn) {
    if (count($segments) === 3) {
        // /api/users (GET, POST)
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $result = $conn->query("SELECT * FROM tm1_users");
            $users = $result->fetch_all(MYSQLI_ASSOC);
            sendResponse(200, $users);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [];

            if (!empty($_POST)) {
                // Data comes from form-data
                $data = $_POST;
            } else {
                // Data comes from JSON
                $data = json_decode(file_get_contents('php://input'), true);
            }
            // Creating a new user
            $stmt = $conn->prepare("INSERT INTO tm1_users (username, password, email, name, surname, date_birth, pfp_image_url) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param(
                'sssssss',
                $data['username'],
                password_hash($data['password'], PASSWORD_DEFAULT),
                $data['email'],
                $data['name'],
                $data['surname'],
                $data['date_birth'],
                $data['pfp_image_url']
            );
            $stmt->execute();
            sendResponse(201, "User created successfully.");
        }
    } elseif (count($segments) === 4) {
        // /api/users/{username} (GET, PUT, DELETE)
        $username = $segments[3];
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $stmt = $conn->prepare("SELECT * FROM tm1_users WHERE username = ? OR email = ?");
            $stmt->bind_param('ss', $username, $username);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            sendResponse(200, $result);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            // Get data from raw JSON
            $data = json_decode(file_get_contents('php://input'), true);
        
            // Fallback to form-data if raw JSON is not provided
            if (!$data) {
                $data = $_POST; // For form-data, it will automatically be parsed
            }
        
            // Ensure that all required fields are present in the data
            if (!isset($data['email'], $data['name'], $data['surname'], $data['date_birth'], $data['pfp_image_url'])) {
                sendResponse(400, "Missing required fields.");
                return;
            }
        
            // Prepare the SQL query to update user details
            $stmt = $conn->prepare("UPDATE tm1_users SET email = ?, name = ?, surname = ?, date_birth = ?, pfp_image_url = ? WHERE username = ?");
            $stmt->bind_param(
                'ssssss', // Bind the parameters as strings
                $data['email'],
                $data['name'],
                $data['surname'],
                $data['date_birth'],
                $data['pfp_image_url'],
                $username
            );
            $stmt->execute();
        
            // Check if the update was successful
            if ($stmt->affected_rows > 0) {
                sendResponse(200, "User updated successfully.");
            } else {
                sendResponse(400, "No changes were made.");
            }

        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            $stmt = $conn->prepare("DELETE FROM tm1_users WHERE username = ?");
            $stmt->bind_param('s', $username);
            $stmt->execute();

            $stmt = $conn->prepare("DELETE FROM tm1_user_task WHERE id_user = ?");
            $stmt->bind_param('s', $username);
            $stmt->execute();

            $stmt = $conn->prepare("DELETE FROM tm1_user_project WHERE id_user = ?");
            $stmt->bind_param('s', $username);
            $stmt->execute();

            sendResponse(200, "User deleted successfully.");
        }
    } elseif (count($segments) === 5) {
        $username = $segments[3];
        if($_SERVER['REQUEST_METHOD'] === 'GET'){
            if($segments[4] == "img"){
                $stmt = $conn->prepare("SELECT pfp_image_url FROM tm1_users WHERE username = ?");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_assoc();
                sendResponse(200, $result);
            } else if ($segments[4] == "tasks") {
                $stmt = $conn->prepare("
                    SELECT 
                        t.id AS task_id, 
                        t.title, 
                        t.description, 
                        t.date_creation, 
                        t.priority_level, 
                        t.date_start, 
                        t.date_completion, 
                        t.is_completed, 
                        ut.advancement_perc 
                    FROM tm1_tasks t
                    JOIN tm1_user_task ut ON t.id = ut.id_task
                    WHERE ut.id_user = ?
                ");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                // Respond with the tasks
                sendResponse(200, $result);
            } else if ($segments[4] == "projects") {
                $stmt = $conn->prepare("
                    SELECT 
                        p.id AS project_id, 
                        p.title, 
                        p.description, 
                        p.date_creation, 
                        up.id_role 
                    FROM tm1_projects p
                    JOIN tm1_user_project up ON p.id = up.id_project
                    WHERE up.id_user = ?
                ");
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                // Respond with the projects
                sendResponse(200, $result);
            }
        } 
    } else {
        sendResponse(400, "Invalid user endpoint.");
    }
}

function handleProjects($segments, $conn) {
    if (count($segments) === 3) {
        // /api/projects (GET, POST)
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $result = $conn->query("SELECT * FROM tm1_projects");
            $projects = $result->fetch_all(MYSQLI_ASSOC);
            sendResponse(200, $projects);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [];
            if (!empty($_POST)) {
                // Data comes from form-data
                $data = $_POST;
            } else {
                // Data comes from JSON
                $data = json_decode(file_get_contents('php://input'), true);
            }
            $stmt = $conn->prepare("INSERT INTO tm1_projects (title, description, date_creation, id_creator) VALUES (?, ?, NOW(), ?)");
            $stmt->bind_param(
                'sss',
                $data['title'],
                $data['description'],
                $data['id_creator']
            );
            $stmt->execute();
            sendResponse(201, "Project created successfully.");
        }
    } elseif (count($segments) === 4) {
        // /api/projects/{projectId} (GET, PUT, DELETE)
        $projectId = $segments[3];
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $stmt = $conn->prepare("SELECT * FROM tm1_projects WHERE id = ?");
            $stmt->bind_param('i', $projectId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            sendResponse(200, $result);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            $data = [];
            $data = json_decode(file_get_contents('php://input'), true);
            
            $stmt = $conn->prepare("UPDATE tm1_projects SET title = ?, description = ? WHERE id = ?");
            $stmt->bind_param(
                'ssi',
                $data['title'],
                $data['description'],
                $projectId
            );
            $stmt->execute();
            sendResponse(200, "Project updated successfully.");
        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            $stmt = $conn->prepare("DELETE FROM tm1_projects WHERE id = ?");
            $stmt->bind_param('i', $projectId);
            $stmt->execute();
            sendResponse(200, "Project deleted successfully.");
        }
    } elseif (count($segments) === 5) {
        $projectId = $segments[3];
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            if($segments[4] == 'tasks') {
                $stmt = $conn->prepare("SELECT * FROM tm1_tasks WHERE id_project = ?");
                $stmt->bind_param('i', $projectId);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); // Fetch all rows
                sendResponse(200, $result);
            } else if($segments[4] == 'documents') {
                $stmt = $conn->prepare("SELECT * FROM tm1_project_files WHERE id_project = ?");
                $stmt->bind_param('i', $projectId);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); // Fetch all rows
                sendResponse(200, $result);
            }
            else if($segments[4] == 'participants') {
                $stmt = $conn->prepare("SELECT u.* FROM tm1_users u JOIN tm1_user_project up ON u.username = up.id_user WHERE up.id_project = ?");
                $stmt->bind_param('i', $projectId);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); // Fetch all rows
                sendResponse(200, $result);
            }
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if($segments[4] == 'tasks') {
                $data = [];
                if (!empty($_POST)) {
                    // Data comes from form-data
                    $data = $_POST;
                } else {
                    // Data comes from JSON
                    $data = json_decode(file_get_contents('php://input'), true);
                }
                $stmt = $conn->prepare("INSERT INTO tm1_tasks (title, description, date_creation, priority_level, date_start, date_completion, is_completed, id_project) 
                                        VALUES (?, ?, NOW(), ?, ?, ?, ?, ?)");
                $stmt->bind_param(
                    'ssisssi',
                    $data['title'],
                    $data['description'],
                    $data['priority_level'],
                    $data['date_start'],
                    $data['date_completion'],
                    $data['is_completed'],
                    $projectId
                );
                $stmt->execute();
                sendResponse(201, "Task created successfully.");
            } else if($segments[4] == "documents") {
                $data = [];
                if (!empty($_POST)) {
                    // Data comes from form-data
                    $data = $_POST;
                } else {
                    // Data comes from JSON
                    $data = json_decode(file_get_contents('php://input'), true);
                }
                $stmt = $conn->prepare("INSERT INTO tm1_project_files (filename, id_project, uploader) VALUES (?, ?, ?)");
                $stmt->bind_param(
                    'sis',
                    $data['filename'],
                    $projectId,
                    $data['uploader']
                );
                $stmt->execute();
                sendResponse(201, "Document uploaded successfully.");
            }
            else if($segments[4] == "participants") {
                $data = [];
                if (!empty($_POST)) {
                    // Data comes from form-data
                    $data = $_POST;
                } else {
                    // Data comes from JSON
                    $data = json_decode(file_get_contents('php://input'), true);
                }
                
                $stmt = $conn->prepare("INSERT INTO tm1_user_project (id_user, id_project, id_role) VALUES (?, ?, ?)");
                $bind = $stmt->bind_param(
                    'sis',
                    $data['username'],
                    $projectId,
                    $data['id_role']
                );
                $execute = $stmt->execute();
                if ($execute === false) {
                    sendResponse(500, "Error executing the statement: " . $stmt->error);
                } else {
                    sendResponse(201, "User added to project successfully.");
                }
            }
        }
    } else if (count($segments) === 6) {
        $projectId = $segments[3];
        $username = $segments[5];
        if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            $stmt = $conn->prepare('DELETE FROM tm1_user_project WHERE id_user = ? AND id_project = ?');
            $stmt->bind_param('si', $username, $projectId);
            $stmt->execute();
            $stmt = $conn->prepare('DELETE FROM tm1_user_task WHERE id_user = ? AND id_task IN (SELECT id FROM tm1_tasks WHERE id_project = ?)');
            $stmt->bind_param('si', $username, $projectId);
            $stmt->execute();
            sendResponse(200, 'User removed from project successfully.');
        }
    } else if (count($segments) === 7) {
        $projectId = $segments[3];
        $username = $segments[5];
        if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            $data = [];
            $data = json_decode(file_get_contents('php://input'), true);

            $stmt = $conn->prepare("UPDATE tm1_user_project SET id_role = ? WHERE id_user = ? AND id_project = ?");
            $stmt->bind_param(
                'isi',
                $data['id_role'],
                $username,
                $projectId
            );
            $stmt->execute();
            sendResponse(201, "User Role Updated successfully.");
        }
    } else {
        sendResponse(400, "Invalid project endpoint.");
    }
}

function handleTasks($segments, $conn) {
    if (count($segments) === 3) {
        // /api/tasks (GET, POST)
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $result = $conn->query("SELECT * FROM tm1_tasks");
            $tasks = $result->fetch_all(MYSQLI_ASSOC);
            sendResponse(200, $tasks);
        }
    } elseif (count($segments) === 4) {
        // /api/tasks/{taskId} (GET, PUT, DELETE)
        $taskId = $segments[3];
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $stmt = $conn->prepare("SELECT * FROM tm1_tasks WHERE id = ?");
            $stmt->bind_param('i', $taskId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            sendResponse(200, $result);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
            $data = [];
            $data = json_decode(file_get_contents('php://input'), true);

            $stmt = $conn->prepare("UPDATE tm1_tasks SET title = ?, description = ?, priority_level = ?, date_start = ?, date_completion = ?, is_completed = ? WHERE id = ?");
            $stmt->bind_param(
                'ssisssi',
                $data['title'],
                $data['description'],
                $data['priority_level'],
                $data['date_start'],
                $data['date_completion'],
                $data['is_completed'],
                $taskId
            );
            $stmt->execute();
            sendResponse(200, "Task updated successfully.");
        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            $stmt = $conn->prepare("DELETE FROM tm1_tasks WHERE id = ?");
            $stmt->bind_param('i', $taskId);
            $stmt->execute();
            sendResponse(200, "Task deleted successfully.");
        }
    } elseif (count($segments) === 5) {
        $taskId = $segments[3];
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            if($segments[4] == 'modifications') {
                $stmt = $conn->prepare("SELECT * FROM tm1_edits WHERE id_task = ?");
                $stmt->bind_param('i', $taskId);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                sendResponse(200, $result);
            } else if( $segments[4] == 'participants') {
                $stmt = $conn->prepare("SELECT u.* FROM tm1_users u JOIN tm1_user_task ut ON u.username = ut.id_user WHERE ut.id_task = ?");
                $stmt->bind_param('i', $taskId);
                $stmt->execute();
                $result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); // Fetch all rows
                sendResponse(200, $result);
            }
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if($segments[4] == 'participants') {
                $advPercent = 0;
                $data = [];
                if (!empty($_POST)) {
                    // Data comes from form-data
                    $data = $_POST;
                } else {
                    // Data comes from JSON
                    $data = json_decode(file_get_contents('php://input'), true);
                }
                $stmt = $conn->prepare("INSERT INTO tm1_user_task (id_user, id_task, advancement_perc) VALUES (?, ?, ?)");
                $stmt->bind_param(
                    'sii',
                    $data['username'],
                    $taskId,
                    $advPercent
                );
                $stmt->execute();
                sendResponse(201, "User added to task successfully.");
            } else if( $segments[4] == "modifications") {
                $data = [];
                if (!empty($_POST)) {
                    // Data comes from form-data
                    $data = $_POST;
                } else {
                    // Data comes from JSON
                    $data = json_decode(file_get_contents('php://input'), true);
                }
                $stmt = $conn->prepare("INSERT INTO tm1_edits (date_modification, time_modification, id_task, id_user) VALUES (?, ?, ?, ?)");
                $stmt->bind_param(
                    'ssis',
                    $data['date_modification'],
                    $data['time_modification'],
                    $taskId,
                    $data['id_user']
                );
                $stmt->execute();
                sendResponse(201, "Modification logged successfully.");
            }
            if($segments[4] == 'participants') {
                $data = [];
                $data = json_decode(file_get_contents('php://input'), true);
                $stmt = $conn->prepare('DELETE FROM tm1_user_task WHERE id_user = ? AND id_task = ?');
                $stmt->bind_param('si', $data['username'], $taskId);
                $stmt->execute();
                sendResponse(200, 'User removed from task successfully.');
            }
        }
    } else if (count($segments) === 6){
        $taskId = $segments[3];
        if ($_SERVER['REQUEST_METHOD'] === "DELETE") {
            if($segments[4] == 'participants') {
                $username = $segments[5];
                $stmt = $conn->prepare('DELETE FROM tm1_user_task WHERE id_user = ? AND id_task = ?');
                $stmt->bind_param('si', $username, $taskId);
                $stmt->execute();
                sendResponse(200, 'User removed from task successfully.');
            }
        }
    } else {
        sendResponse(400, "Invalid task endpoint.");
    }
}

function handleDocuments($segments, $conn) {
    if (count($segments) === 3) {
        // /api/documents (GET, POST)
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $result = $conn->query("SELECT * FROM tm1_project_files");
            $documents = $result->fetch_all(MYSQLI_ASSOC);
            sendResponse(200, $documents);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [];
            if (!empty($_POST)) {
                // Data comes from form-data
                $data = $_POST;
            } else {
                // Data comes from JSON
                $data = json_decode(file_get_contents('php://input'), true);
            }
            $stmt = $conn->prepare("INSERT INTO tm1_project_files (filename, id_project, uploader) VALUES (?, ?, ?)");
            $stmt->bind_param(
                'sis',
                $data['filename'],
                $data['id_project'],
                $data['uploader']
            );
            $stmt->execute();
            sendResponse(201, "Document uploaded successfully.");
        }
    } elseif (count($segments) === 4) {
        // /api/documents/{documentId} (GET, DELETE)
        $documentId = $segments[3];
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $stmt = $conn->prepare("SELECT * FROM tm1_project_files WHERE id = ?");
            $stmt->bind_param('i', $documentId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            sendResponse(200, $result);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            $stmt = $conn->prepare("DELETE FROM tm1_project_files WHERE id = ?");
            $stmt->bind_param('i', $documentId);
            $stmt->execute();
            sendResponse(200, "Document deleted successfully.");
        }
    } else {
        sendResponse(400, "Invalid document endpoint.");
    }
}

function handleRoles($segments, $conn) {
    if (count($segments) === 3) {
        // /api/roles (GET, POST)
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $result = $conn->query("SELECT * FROM tm1_roles");
            $roles = $result->fetch_all(MYSQLI_ASSOC);
            sendResponse(200, $roles);
        }
    } else {
        sendResponse(400, "Invalid roles endpoint.");
    }
}

function handleModifications($segments, $conn) {
    if (count($segments) === 3) {
        // /api/modifications (GET, POST)
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $result = $conn->query("SELECT * FROM tm1_edits");
            $modifications = $result->fetch_all(MYSQLI_ASSOC);
            sendResponse(200, $modifications);
        } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [];
            if (!empty($_POST)) {
                // Data comes from form-data
                $data = $_POST;
            } else {
                // Data comes from JSON
                $data = json_decode(file_get_contents('php://input'), true);
            }
            $stmt = $conn->prepare("INSERT INTO tm1_edits (date_modification, time_modification, id_task, id_user) VALUES (?, ?, ?, ?)");
            $stmt->bind_param(
                'ssis',
                $data['date_modification'],
                $data['time_modification'],
                $data['id_task'],
                $data['id_user']
            );
            $stmt->execute();
            sendResponse(201, "Modification logged successfully.");
        }
    } else if (count($segments) === 4) {
        $modId = $segments[3];
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $stmt = $conn->prepare("SELECT * FROM tm1_edits WHERE id = ?");
            $stmt->bind_param('i', $modId);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            sendResponse(200, $result);;
        }
    } else {
        sendResponse(400, "Invalid modifications endpoint.");
    }
}


// Helper function to send API responses
function sendResponse($statusCode, $data) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode(["data" => $data]);
    exit;
}

// Close database connection at the end
register_shutdown_function(function () use ($conn) {
    $conn->close();
});